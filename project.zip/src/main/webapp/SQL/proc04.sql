create or replace function cal_bonus( --cal_bonus라는 함수명을 정의
  vempno in emp27.empno%type
)

return number  --함수 실행후 반환되는 자료형 타입

is 
  VSAL number(10,2); 
begin
  select sal into VSAL from emp28 where empno=vempno;
  
  return (VSAL*200);  --급여*200한 값을 반환
end;
/