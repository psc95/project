create or replace procedure sel_empno(
   vempno in emp27.empno%type,
   vename out emp27.ename%type
)
is
begin
  select ename into vename from emp28 where empno=vempno;
end;
/