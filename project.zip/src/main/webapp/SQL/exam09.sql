set serveroutput on

declare
   
begin
  for i in 1..10  --1부터 1씩 증가된 10까지의 자연수가 i반복문 제어변수에 할당
  loop
    DBMS_OUTPUT.PUT_LINE(i);
  end loop;
end;
/