set serveroutput on

declare
  vemp emp27%rowtype; -- 한행 전체 레코드 행값을 로우타입 변수 vemp 저장
  annsal number(10,2);  --10은 소수점을 포함한 전체자리수, 2는 소수점 자리수

begin
  --강감찬 사원의 한행 전체 레코드 행값을  vemp변수에 저장
  select * into vemp from emp27 where ename='강감찬';
  
  if (vemp.comm is null)  then --보너스가 null일때 실행
     annsal := vemp.sal*12;
  else
     annsal := vemp.sal * 12 + vemp.comm; -- 급여*12+보너스
  end if;
  
  DBMS_OUTPUT.PUT_LINE('사원번호  /  사원명   /   연봉');
  DBMS_OUTPUT.PUT_LINE('========================>');
  DBMS_OUTPUT.PUT_LINE(vemp.empno || ' / ' ||  vemp.ename || '  /  ' ||  ANNSAL);
end;
/