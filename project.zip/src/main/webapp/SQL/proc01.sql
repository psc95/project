create or replace procedure DEL_ALL --DEL_ALL이라는 저장프로시저 생성

is
begin
  delete from emp28;
end;
/