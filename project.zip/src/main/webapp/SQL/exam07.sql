set serveroutput on

declare
  vemp emp27%rowtype;
  vdname varchar2(50);
  
begin

   select * into vemp from emp27 where ename='강감찬';
   
   if (vemp.deptno = 10) then
      vdname := '개발부';
   elsif (vemp.deptno = 20) then
     vdname := '관리부';
   else
     vdname := '연구부';
  end if;
  
  DBMS_OUTPUT.PUT_LINE('부서번호  /  사원명   /   부서명');
  DBMS_OUTPUT.PUT_LINE('=======================>');
  DBMS_OUTPUT.PUT_LINE(vemp.deptno || ' / ' ||  vemp.ename || ' /  ' ||  vdname);
end;
/