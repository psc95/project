set serveroutput on

declare
  i number(38) := 1;
  total number(38) := 0; --누적합
  
begin
  while i <= 100
  
  loop
     total := total + i;
     i := i + 1;  --1씩 증가
  end loop;
  
  DBMS_OUTPUT.PUT_LINE('1부터 100까지의 누적합 = ' ||  total );
end;
/