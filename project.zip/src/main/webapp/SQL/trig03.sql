create or replace trigger trg_03
after delete on emp01 --emp01테이블 레코드 삭제이후 begin~end사이 문장이 수행되는 트리거

for each row
begin
  delete from sal01 where empno = :old.empno;
end;
/