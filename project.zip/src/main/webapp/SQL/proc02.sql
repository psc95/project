create or replace procedure DEL_NAME(
   vename emp27.ename%type
)
is
begin
  delete from emp28 where ename=vename;
end;
/