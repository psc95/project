set serveroutput on

declare
/* 레코드 타입 정의 => 여러개의 컬럼을 묶어서 하나의 레코드 타입 변수로 선언해야 하는 경우 사용한다. 테이블의 여러개의 컬럼의 한
행의 레코드 값을 저장할 때 레코드 타입 변수를 사용하면 편리하다.
*/
type emp_record_type is record( -- 레코드 타입 emp_record_type을 정의
   v_empno emp27.empno%type,
   v_ename emp27.ename%type,
   v_LOC emp27.LOC%type,
   v_deptno emp27.deptno%type
);

 emp_record emp_record_type ;--레코드 타입 변수 emp_record를 정의
 
begin
  select empno,ename,LOC,deptno into emp_record from emp27 where ename='강감찬';
  --강감찬 사원의 사원번호,사원명,사는지역,부서번호를 레코드 타입변수 emp_record에 저장
  
  --레코드 타입변수에 저장된 값을 출력
  DBMS_OUTPUT.PUT_LINE('사원번호 : ' ||  emp_record.v_empno);
  DBMS_OUTPUT.PUT_LINE('사원명 : ' || emp_record.v_ename);
  DBMS_OUTPUT.PUT_LINE('사는지역: ' || emp_record.v_LOC);
  DBMS_OUTPUT.PUT_LINE('부서번호:' || emp_record.v_deptno);
end;
/



