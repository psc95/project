create or replace trigger trg_01 --trg_01 트리거 생성
 
 after insert on emp01 --emp01 테이블에 레코드 저장후 begin~end사이의 문장이 실행된다.
 
 begin
   DBMS_OUTPUT.PUT_LINE('Thank YOU !! *^^*');
 end;
 /