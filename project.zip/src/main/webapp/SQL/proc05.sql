set serveroutput on

create or replace procedure cursor_sample01

is
vemp emp29%rowtype; --로우타입 변수 정의

cursor c1 --c1커서 정의(커서를 사용하는 이유는 하나이상의 복수개의 레코드 행값을 반환하기 위해서 이다.)
is
select * from emp29;

begin
  DBMS_OUTPUT.PUT_LINE('empno   /  ename  / LOC');
  DBMS_OUTPUT.PUT_LINE('======================');
  
  OPEN c1;  --c1커서 열기
    LOOP
      fetch c1 into vemp.empno, vemp.ename, vemp.LOC; --C1 커서로 부터 레코드값을 읽어와서 각 변수에 저장
      
      EXIT WHEN C1%notfound; --c1커서로 부터 더 이상 읽을 값이 없다면 반복문을 빠져 나간다.
      DBMS_OUTPUT.PUT_LINE(vemp.empno  || '  /  ' || vemp.ename ||  '  /  ' || vemp.LOC);
    END LOOP;
  CLOSE C1; --커서 닫기
end;
/