package net.daum.vo;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class MailVO {

	private String address;//멜주소
	private String title;//멜제목
	private String content;//멜 내용
	
}
